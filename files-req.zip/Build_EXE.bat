@echo off
setlocal

echo ============================================
echo   Build standalone CoC_Bot.exe (PyInstaller)
echo ============================================
echo.
echo This must be run on Windows (an exe built elsewhere won't run
echo on Windows). It packages coc_bot.py + your Python environment
echo into a single CoC_Bot.exe in the "dist" folder.
echo.

cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python not found on PATH. Install it from python.org first.
    pause
    exit /b 1
)

echo Installing build dependencies...
python -m pip install --upgrade pip >nul 2>nul
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies.
    pause
    exit /b 1
)

echo.
echo Building CoC_Bot.exe ...
python -m PyInstaller --onefile --noconsole --name CoC_Bot ^
    --add-data "All_Tags.json;." ^
    coc_bot.py

if errorlevel 1 (
    echo.
    echo [ERROR] Build failed. See errors above.
    pause
    exit /b 1
)

echo.
echo Done! Your executable is at: dist\CoC_Bot.exe
echo.
echo IMPORTANT: All_Tags.json is bundled inside the exe, but if you
echo edit/re-tag your buttons later you'll need to rebuild the exe
echo (or just run coc_bot.py directly with Start_Bot.bat instead,
echo which always reads the current All_Tags.json from disk).
echo.
pause
endlocal
