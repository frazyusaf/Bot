"""
Clash of Clans Attack-Loop Bot
==============================
Reads click/drag regions from All_Tags.json and replays the attack
sequence: Attack -> Find Match -> Deploy spells/troops -> Wait -> End
Battle -> Return Home -> repeat.

REQUIREMENTS
------------
    pip install pyautogui

BEFORE YOU RUN THIS
--------------------
1. Put All_Tags.json in the same folder as this script (or change
   TAGS_FILE below).
2. Set REFERENCE_WIDTH / REFERENCE_HEIGHT to the resolution the
   coordinates in the JSON were captured at. Your JSON's max
   coordinates are ~2464 x ~1090, which strongly suggests a capture
   at 2560x1440. If you tagged the screenshot at a different
   resolution, change these two numbers.
3. Make sure the game window / emulator is positioned at (0,0) on
   your screen (top-left corner), maximized, and stays in the exact
   same spot every time the bot runs. If your emulator window has
   a title bar / borders, either run it borderless or add an
   OFFSET_X / OFFSET_Y below.
4. Run `python calibrate.py` (included) first to sanity check a few
   points before trusting the bot with a real match.

SAFETY
------
- pyautogui.FAILSAFE is ON: slam your mouse into the top-left corner
  of the screen at any time to immediately abort.
- Ctrl+C in the terminal also stops the bot cleanly.
"""

import json
import math
import random
import sys
import time
from pathlib import Path

try:
    import pyautogui
except ImportError:
    sys.exit("pyautogui is not installed. Run: pip install pyautogui")

# --------------------------------------------------------------------------
# CONFIG - edit these to match your setup
# --------------------------------------------------------------------------

TAGS_FILE = Path(__file__).parent / "All_Tags.json"

# Resolution the JSON coordinates were captured at.
REFERENCE_WIDTH = 2560
REFERENCE_HEIGHT = 1440

# If your emulator window doesn't start at the top-left corner of the
# screen, set these (in actual screen pixels).
OFFSET_X = 0
OFFSET_Y = 0

# Deploy counts per your spec
SPELL1_DEPLOY1_COUNT = 4   # Spell 01 -> Spell Deploy 01 x4
SPELL1_DEPLOY2_COUNT = 4   # Spell 01 -> spell deploy 02 x4
SPELL2_DEPLOY1_COUNT = 1   # Spell 02 -> Spell Deploy 01 x1
SPELL2_DEPLOY2_COUNT = 1   # Spell 02 -> spell deploy 02 x1

WAIT_AFTER_BATTLE_START = 3     # seconds, after step 3 (03- Attack Button)
WAIT_AFTER_DEPLOY = 40          # seconds, before ending battle

# Troop deploy counts per your spec (Valkyries spread across the 3 lines)
VALK_AREA01_COUNT = 6
VALK_AREA02_COUNT = 6
VALK_AREA03_COUNT = 30

# Taps for the hero group-deploy on Deploy area 03 after all 4 heroes are
# selected. Default is 1 (single tap deploys the selected group). Bump this
# to 4 if your game/setup needs one tap per hero instead.
HERO_DEPLOY_TAPS = 1

# Humanizing - random delay so every click isn't identically timed
MIN_DELAY = 0.25
MAX_DELAY = 0.55

# Rectangle regions: click a random point inside the button's full
# clickable area (not the same pixel every time). PADDING_RATIO shrinks
# the box slightly inward (0.15 = ignore outer 15% of each edge) so we
# never click right on the border of a button and miss it.
RECT_PADDING_RATIO = 0.15

# 0 = run forever, otherwise stop after N attacks
MAX_LOOPS = 0

# Line regions (troop/spell deploy lines): sideways jitter in pixels
# (reference-resolution units) so troops don't all land in a dead-
# straight overlapping row, plus per-tap timing.
LINE_PERP_JITTER_PX = 12
LINE_TAP_MIN_DELAY = 0.08
LINE_TAP_MAX_DELAY = 0.20

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.1

# --------------------------------------------------------------------------
# LOAD REGIONS
# --------------------------------------------------------------------------

def load_regions(path: Path) -> dict:
    data = json.loads(path.read_text())
    regions = {}
    for r in data["regions"]:
        regions[r["tag"]] = r
    return regions


REGIONS = load_regions(TAGS_FILE)

screen_w, screen_h = pyautogui.size()
SCALE_X = screen_w / REFERENCE_WIDTH
SCALE_Y = screen_h / REFERENCE_HEIGHT


def scale_point(x, y):
    return (
        OFFSET_X + int(x * SCALE_X),
        OFFSET_Y + int(y * SCALE_Y),
    )


def human_delay():
    time.sleep(random.uniform(MIN_DELAY, MAX_DELAY))


def random_point_in_rect(r):
    """Pick a random point inside the rectangle, inset by RECT_PADDING_RATIO
    on each edge so we stay well clear of the button's border."""
    w = r["x2"] - r["x1"]
    h = r["y2"] - r["y1"]
    pad_x = w * RECT_PADDING_RATIO
    pad_y = h * RECT_PADDING_RATIO
    x = random.uniform(r["x1"] + pad_x, r["x2"] - pad_x)
    y = random.uniform(r["y1"] + pad_y, r["y2"] - pad_y)
    return x, y


# --------------------------------------------------------------------------
# LOW-LEVEL ACTIONS
# --------------------------------------------------------------------------

def click_tag(tag: str, log=True):
    """Click a rectangle region at a random point within its bounds so the
    bot never clicks the exact same pixel twice in a row."""
    r = REGIONS.get(tag)
    if r is None:
        raise KeyError(f"Tag '{tag}' not found in {TAGS_FILE.name}")
    if r["shape"] != "rectangle":
        raise ValueError(f"Tag '{tag}' is not a rectangle, use deploy_on_line() instead")

    rx, ry = random_point_in_rect(r)
    x, y = scale_point(rx, ry)

    if log:
        print(f"  [click] {tag}  -> ({x}, {y})")
    pyautogui.moveTo(x, y, duration=random.uniform(0.08, 0.18))
    pyautogui.click()
    human_delay()


def click_tag_n(tag: str, count: int):
    for _ in range(count):
        click_tag(tag)


def deploy_on_line(tag: str, count: int, log=True):
    """Deploy `count` troops spread along a line region. Each troop lands
    at a random point along the line (never the exact endpoints), with a
    small sideways jitter perpendicular to the line so troops fan out
    naturally instead of stacking in a dead-straight row."""
    r = REGIONS.get(tag)
    if r is None:
        raise KeyError(f"Tag '{tag}' not found in {TAGS_FILE.name}")
    if r["shape"] != "line":
        raise ValueError(f"Tag '{tag}' is not a line, use click_tag() instead")

    x1, y1, x2, y2 = r["x1"], r["y1"], r["x2"], r["y2"]
    dx, dy = x2 - x1, y2 - y1
    length = math.hypot(dx, dy) or 1.0
    perp_x, perp_y = -dy / length, dx / length  # unit vector perpendicular to line

    if log:
        print(f"  [deploy] {tag} x{count}")

    for i in range(count):
        t = random.uniform(0.08, 0.92)  # stay off the extreme endpoints
        px = x1 + dx * t
        py = y1 + dy * t
        offset = random.uniform(-LINE_PERP_JITTER_PX, LINE_PERP_JITTER_PX)
        px += perp_x * offset
        py += perp_y * offset

        sx, sy = scale_point(px, py)
        pyautogui.moveTo(sx, sy, duration=random.uniform(0.04, 0.1))
        pyautogui.click()
        time.sleep(random.uniform(LINE_TAP_MIN_DELAY, LINE_TAP_MAX_DELAY))


# --------------------------------------------------------------------------
# ATTACK SEQUENCE
# --------------------------------------------------------------------------

def run_attack_sequence(attack_num: int):
    print(f"\n=== Attack #{attack_num} ===")

    # 1. Open attack menu
    click_tag("Attack Button")

    # 2. Find a match
    click_tag("Find a Match")

    # 3. Start the battle (opponent found)
    click_tag("03- Attack Button")
    print(f"  waiting {WAIT_AFTER_BATTLE_START}s for battle to load...")
    time.sleep(WAIT_AFTER_BATTLE_START)

    # 4. Spell 01 -> deploy both spell points
    click_tag("Spell 01 Select")
    click_tag_n("Spell Deploy 01", SPELL1_DEPLOY1_COUNT)
    click_tag_n("spell deploy 02", SPELL1_DEPLOY2_COUNT)

    # 5. Spell 02 -> deploy once each
    click_tag("Spell 02 select")
    click_tag_n("Spell Deploy 01", SPELL2_DEPLOY1_COUNT)
    click_tag_n("spell deploy 02", SPELL2_DEPLOY2_COUNT)

    # 8. Select Valkyries
    click_tag("04- Valk Select")

    # 9-11. Deploy Valkyries: 6 on area 01, 6 on area 02, 30 on area 03
    deploy_on_line("Deploy area 01", VALK_AREA01_COUNT)
    deploy_on_line("Deploy area 02", VALK_AREA02_COUNT)
    deploy_on_line("Deploy area 03", VALK_AREA03_COUNT)

    # 12. Select all 4 heroes, deploy on line 03 again
    click_tag("Hero 01 Select")
    click_tag("Hero 02 Select")
    click_tag("Hero 03 select")
    click_tag("Hero 04 select")
    deploy_on_line("Deploy area 03", HERO_DEPLOY_TAPS)

    print(f"  waiting {WAIT_AFTER_DEPLOY}s for battle to play out...")
    time.sleep(WAIT_AFTER_DEPLOY)

    # 13. End battle
    click_tag("End Battle")

    # 14. Confirm
    click_tag("Okay Button")

    # 15. Return home
    click_tag("Return Home Button")

    print(f"=== Attack #{attack_num} complete ===")


# --------------------------------------------------------------------------
# MAIN LOOP
# --------------------------------------------------------------------------

def main():
    print(f"Screen resolution detected: {screen_w}x{screen_h}")
    print(f"Reference resolution:       {REFERENCE_WIDTH}x{REFERENCE_HEIGHT}")
    print(f"Scale factor:               x={SCALE_X:.3f}  y={SCALE_Y:.3f}")
    print(f"Loaded {len(REGIONS)} regions from {TAGS_FILE.name}")
    print("Move your mouse to the top-left corner of the screen at any")
    print("time to abort (pyautogui failsafe). Ctrl+C also works.\n")
    print("Starting in 5 seconds - switch to your emulator window now...")
    time.sleep(5)

    attack_num = 0
    try:
        while MAX_LOOPS == 0 or attack_num < MAX_LOOPS:
            attack_num += 1
            run_attack_sequence(attack_num)
            # brief pause before starting the next attack
            time.sleep(random.uniform(1.5, 3.0))
    except pyautogui.FailSafeException:
        print("\nFailsafe triggered - bot stopped.")
    except KeyboardInterrupt:
        print("\nStopped by user (Ctrl+C).")


if __name__ == "__main__":
    main()
